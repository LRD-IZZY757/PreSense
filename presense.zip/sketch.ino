/*
  Presense — occupancy-state room automation
  Arduino Uno | 3x HC-SR501 | 2x relay module | 16x2 I2C LCD | 2 buttons

  States: EMPTY -> ACTIVE -> WARNING -> SLEEPING -> EXITING -> EMPTY

  P1/P2 at the doorway resolve direction (entry vs exit).
  P3 monitors the room interior to distinguish an active occupant
  from one at rest. PIR cannot confirm sleep, only stillness, so the
  system warns before sleeping and offers a manual snooze.

  P3 PLACEMENT MATTERS: it must not see the doorway (corridor traffic
  resets the timer) or the ceiling fan (permanent motion = never sleeps).
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---------------- Pins ----------------
const uint8_t P1_PIN      = 2;   // entrance exterior
const uint8_t P2_PIN      = 3;   // entrance interior
const uint8_t P3_PIN      = 4;   // room interior (activity)
const uint8_t RELAY_FAN   = 5;   // CH2 sleep-essential
const uint8_t LED_PIN     = 6;   // status indicator
const uint8_t RELAY_LIGHT = 7;   // CH1 wake-only
const uint8_t BTN_MODE    = 8;   // AUTO / FORCE ON / FORCE OFF
const uint8_t BTN_SNOOZE  = 9;   // suspend sleep mode
// LCD SDA = A4, SCL = A5

// ---------------- Config ----------------
#define DEMO_MODE 1              // 1 = short timers for judging, 0 = real

const bool RELAY_ACTIVE_LOW = false;

const unsigned long DEBOUNCE_MS   = 50;
const unsigned long SEQ_WINDOW_MS = 3000;

#if DEMO_MODE
  const unsigned long SLEEP_MS  = 30000UL;              // 30 s
  const unsigned long SNOOZE_MS = 60000UL;              // 1 min
  const unsigned long EXIT_MS   = 20000UL;              // 20 s
  const unsigned long STALE_MS  = 60000UL;              // 1 min
#else
  const unsigned long SLEEP_MS  = 20UL * 60UL * 1000UL; // 20 min
  const unsigned long SNOOZE_MS = 60UL * 60UL * 1000UL; // 1 hour
  const unsigned long EXIT_MS   = 2UL * 60UL * 1000UL;  // 2 min
  const unsigned long STALE_MS  = 30UL * 60UL * 1000UL; // 30 min
#endif

const unsigned long WARN_MS  = 10000UL;   // warning window before sleep
const unsigned long BLINK_MS = 400UL;     // warning blink rate

// ---------------- Debounced input ----------------
struct Debounced {
  uint8_t pin;
  bool stable;
  bool lastRaw;
  unsigned long lastChange;
};

Debounced p1 = {P1_PIN, false, false, 0};
Debounced p2 = {P2_PIN, false, false, 0};
Debounced p3 = {P3_PIN, false, false, 0};

// Buttons are debounced the same way — mechanical contacts bounce
// several times per press and would otherwise multi-trigger the mode.
Debounced bMode   = {BTN_MODE,   true, true, 0};
Debounced bSnooze = {BTN_SNOOZE, true, true, 0};

void updateDebounced(Debounced &d, unsigned long now) {
  bool raw = digitalRead(d.pin);
  if (raw != d.lastRaw) {
    d.lastRaw = raw;
    d.lastChange = now;
  } else if ((now - d.lastChange) >= DEBOUNCE_MS) {
    d.stable = raw;
  }
}

// ---------------- Doorway sequence ----------------
enum SeqState { SEQ_IDLE, SEQ_ARMED, SEQ_COOLDOWN };
SeqState seqState = SEQ_IDLE;
uint8_t firstSensor = 0;
unsigned long seqStart = 0;

int occupants = 0;
unsigned long lastDoorMotion = 0;

// ---------------- Room state ----------------
enum RoomState { EMPTY, ACTIVE, WARNING, SLEEPING, EXITING };
RoomState room = EMPTY;
const char *ROOM_NAME[] = {"EMPTY", "ACTIVE", "WARNING", "SLEEPING", "EXITING"};

unsigned long lastActivity = 0;
unsigned long warnStart = 0;
unsigned long exitStart = 0;

bool lightsOn = false;
bool fanOn    = false;

// ---------------- Snooze ----------------
bool snoozeActive = false;
unsigned long snoozeStart = 0;

// ---------------- Override ----------------
enum Mode { AUTO, FORCE_ON, FORCE_OFF };
Mode mode = AUTO;
bool modeBtnLast   = HIGH;
bool snoozeBtnLast = HIGH;

void setup() {
  // Drive the relay pins LOW first — before anything slow like the LCD.
  pinMode(RELAY_LIGHT, OUTPUT);
  pinMode(RELAY_FAN, OUTPUT);
  writeRelay(RELAY_LIGHT, false);
  writeRelay(RELAY_FAN, false);

  pinMode(P1_PIN, INPUT);
  pinMode(P2_PIN, INPUT);
  pinMode(P3_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BTN_MODE, INPUT_PULLUP);
  pinMode(BTN_SNOOZE, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("    PRESENSE    ");
  lcd.setCursor(0, 1);
  lcd.print("Initialising...");
  delay(1500);
  lcd.clear();

  Serial.begin(9600);
  lastDoorMotion = millis();
  lastActivity   = millis();
}

void loop() {
  unsigned long now = millis();

  updateDebounced(p1, now);
  updateDebounced(p2, now);
  updateDebounced(p3, now);

  handleButtons(now);
  handleDoorway(now);
  handleActivity(now);
  handleState(now);
  applyOutputs(now);
  updateDisplay(now);
  debugPrint();

  delay(20);
}

// ---------------- Doorway: entry / exit ----------------
void handleDoorway(unsigned long now) {
  bool a = p1.stable;
  bool b = p2.stable;

  switch (seqState) {
    case SEQ_IDLE:
      if (a && !b)      { firstSensor = 1; seqState = SEQ_ARMED; seqStart = now; }
      else if (b && !a) { firstSensor = 2; seqState = SEQ_ARMED; seqStart = now; }
      else if (a && b)  { seqState = SEQ_COOLDOWN; }   // ambiguous, discard
      break;

    case SEQ_ARMED:
      if (firstSensor == 1 && b) {            // P1 -> P2 = entry
        occupants++;
        lastActivity = now;
        seqState = SEQ_COOLDOWN;
      } else if (firstSensor == 2 && a) {     // P2 -> P1 = exit
        if (occupants > 0) occupants--;
        seqState = SEQ_COOLDOWN;
      } else if (now - seqStart > SEQ_WINDOW_MS) {
        seqState = SEQ_COOLDOWN;              // approached, turned back
      }
      break;

    case SEQ_COOLDOWN:
      if (!a && !b) { seqState = SEQ_IDLE; firstSensor = 0; }
      break;
  }

  if (a || b) lastDoorMotion = now;
}

// ---------------- Interior activity ----------------
void handleActivity(unsigned long now) {
  if (p3.stable)    lastActivity = now;
  if (snoozeActive) lastActivity = now;   // snooze freezes sleep AND stale timers

  // Safety net: total silence for a long time means the count is wrong.
  if (occupants > 0 &&
      (now - lastActivity   > STALE_MS) &&
      (now - lastDoorMotion > STALE_MS)) {
    occupants = 0;
  }
}

// ---------------- State machine ----------------
void handleState(unsigned long now) {

  if (snoozeActive && (now - snoozeStart >= SNOOZE_MS)) snoozeActive = false;

  if (occupants > 0) {

    if (room == EMPTY || room == EXITING) {
      room = ACTIVE;
      lastActivity = now;
    }

    if (snoozeActive) {
      // Sleep suspended — any occupancy counts as active.
      if (room == WARNING || room == SLEEPING) {
        room = ACTIVE;
        lastActivity = now;
      }
    } else {
      if (room == ACTIVE && (now - lastActivity > SLEEP_MS - WARN_MS)) {
        room = WARNING;
        warnStart = now;
      }
      if (room == WARNING) {
        if (p3.stable) {                         // any motion cancels
          room = ACTIVE;
          lastActivity = now;
        } else if (now - warnStart >= WARN_MS) {
          room = SLEEPING;
        }
      }
      if (room == SLEEPING && p3.stable) {
        room = ACTIVE;
        lastActivity = now;
      }
    }

  } else {
    if (room != EMPTY && room != EXITING) {
      room = EXITING;
      exitStart = now;
    }
    if (room == EXITING && (now - exitStart >= EXIT_MS)) {
      room = EMPTY;
      snoozeActive = false;
    }
  }

  // Load decisions
  switch (room) {
    case ACTIVE:
    case WARNING:
      lightsOn = true;
      fanOn    = true;
      break;
    case SLEEPING:
      lightsOn = false;     // wake-only load off
      fanOn    = true;      // sleep-essential load stays
      break;
    case EXITING:
      lightsOn = false;     // room is empty — no reason to light it
      fanOn    = true;      // held in case the occupant returns
      break;
    case EMPTY:
      lightsOn = false;
      fanOn    = false;
      break;
  }
}

// ---------------- Outputs ----------------
void writeRelay(uint8_t pin, bool on) {
  digitalWrite(pin, RELAY_ACTIVE_LOW ? !on : on);
}

void applyOutputs(unsigned long now) {
  bool l = lightsOn, f = fanOn;

  // Blink the lights during the warning window as the visible cue.
  if (room == WARNING && l) {
    l = ((now / BLINK_MS) % 2 == 0);
  }

  if (mode == FORCE_ON)  { l = true;  f = true;  }
  if (mode == FORCE_OFF) { l = false; f = false; }

  writeRelay(RELAY_LIGHT, l);
  writeRelay(RELAY_FAN, f);
  digitalWrite(LED_PIN, (l || f) ? HIGH : LOW);
}

// ---------------- Buttons ----------------
void handleButtons(unsigned long now) {
  updateDebounced(bMode, now);
  updateDebounced(bSnooze, now);

  bool m = bMode.stable;
  if (m != modeBtnLast) {
    modeBtnLast = m;
    if (m == LOW) {
      if (mode == AUTO)          mode = FORCE_ON;
      else if (mode == FORCE_ON) mode = FORCE_OFF;
      else                       mode = AUTO;
    }
  }

  bool s = bSnooze.stable;
  if (s != snoozeBtnLast) {
    snoozeBtnLast = s;
    if (s == LOW) {
      snoozeActive = !snoozeActive;      // press again to cancel
      snoozeStart  = now;
      lastActivity = now;
      if (snoozeActive && (room == WARNING || room == SLEEPING)) room = ACTIVE;
    }
  }
}

// ---------------- LCD ----------------
void updateDisplay(unsigned long now) {
  char line1[17];
  char modeTag   = (mode == AUTO) ? ' ' : (mode == FORCE_ON ? '1' : '0');
  char snoozeTag = snoozeActive ? 'S' : ' ';
  snprintf(line1, sizeof(line1), "Occupants: %-2d %c%c",
           occupants, snoozeTag, modeTag);
  lcd.setCursor(0, 0);
  lcd.print(line1);

  char line2[17];
  if (room == WARNING) {
    unsigned long left = (WARN_MS - (now - warnStart)) / 1000UL;
    snprintf(line2, sizeof(line2), "Sleeping in %2lus ", left);
  } else if (room == EXITING) {
    unsigned long left = (EXIT_MS - (now - exitStart)) / 1000UL;
    snprintf(line2, sizeof(line2), "Timer: %02lu:%02lu    ",
             left / 60UL, left % 60UL);
  } else {
    snprintf(line2, sizeof(line2), "Status: %-8s", ROOM_NAME[room]);
  }
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

// ---------------- Serial ----------------
void debugPrint() {
  static unsigned long lastPrint = 0;
  if (millis() - lastPrint < 500) return;
  lastPrint = millis();

  Serial.print("P1:");    Serial.print(p1.stable);
  Serial.print(" P2:");   Serial.print(p2.stable);
  Serial.print(" P3:");   Serial.print(p3.stable);
  Serial.print(" Occ:");  Serial.print(occupants);
  Serial.print(" Room:"); Serial.print(ROOM_NAME[room]);
  Serial.print(" Snz:");  Serial.print(snoozeActive);
  Serial.print(" L:");    Serial.print(lightsOn);
  Serial.print(" F:");    Serial.println(fanOn);
}